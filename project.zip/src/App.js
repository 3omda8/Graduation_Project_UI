import logo from './logo.svg';
import './App.css';
import './components/webpage.css'
import React, { useEffect } from 'react';
import Button from './components/button';
import Navbar from './components/navbar';
import Card from './components/webpage';
import axios from 'axios';

export default function App() {

  useEffect(() => {axios.get('http://localhost:4000/comments').then(res => console.log(res.data))
  .catch(err => console.log(err))})

  return (
<>
<body>

    <Navbar />
    <br/> <br/> <br/> <br/> <br/> <br/>
    <Button />
    <br/> <br/> <br/>
    <div  className='custom'>
    <Card title='Our Services' link="https://www.youtube.com/" />
    <Card title='About' link="https://www.google.com.eg/" />
    <Card title='Contact Us'/>
    </div>

</body>   
</>

  )


 
  
  
}


